# COMP1073-MidTerm

MidTerm Exam Template for COMP1073 - Client-Side Scripting @ Georgian College
